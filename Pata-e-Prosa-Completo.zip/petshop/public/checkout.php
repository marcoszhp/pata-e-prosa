<?php require __DIR__.'/../includes/layout.php'; page_start('Seu mimo está quase a caminho', 'checkout'); ?>
<section class="page-intro"><div class="container"><div class="breadcrumbs"><a href="carrinho.php">Carrinho</a><span>/</span>Finalizar pedido</div><span class="eyebrow">MAIS UM PASSINHO</span><h1>Quase na hora de abanar o rabinho.</h1><p>Confira os detalhes para finalizar o seu pedido.</p></div></section><section class="section"><div class="container" id="checkout-content"><p class="loading">Preparando seu pedido…</p></div></section>
<?php page_end(); ?>
