<?php require __DIR__.'/../includes/layout.php'; page_start('Sua sacola de carinho', 'cart'); ?>
<section class="page-intro"><div class="container"><div class="breadcrumbs"><a href="index.php">Início</a><span>/</span>Carrinho</div><span class="eyebrow">JÁ ESTÁ QUASE NA HORA DO MIMO</span><h1>Sua sacola de carinho.</h1><p>Tem felicidade esperando para chegar aí.</p></div></section><section class="section"><div class="container" id="cart-content"><p class="loading">Abrindo sua sacola…</p></div></section>
<?php page_end(); ?>
