<?php header('Location: login.php?cadastro=1'); exit;
