<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/includes/bootstrap.php';

try {
    $action = is_string($_GET['action'] ?? null) ? $_GET['action'] : 'session';
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $readActions = ['session', 'products', 'product', 'account'];
    $writeActions = ['register', 'login', 'logout', 'profile', 'checkout', 'appointment', 'contact'];
    if (!in_array($action, array_merge($readActions, $writeActions), true)) {
        pp_fail('Esta operação não existe.', 404);
    }
    $expectedMethod = in_array($action, $readActions, true) ? 'GET' : 'POST';
    if ($method !== $expectedMethod) {
        header('Allow: ' . $expectedMethod);
        pp_fail('Método não permitido para esta operação.', 405);
    }
    if ($method === 'POST') {
        $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['csrf'], $token)) {
            pp_fail('Sua sessão de segurança foi atualizada. Recarregue a página e tente novamente.', 419);
        }
        $input = pp_input();
    }

    if ($action === 'session') {
        pp_json(['ok' => true, 'user' => pp_user(), 'csrf' => $_SESSION['csrf'], 'configured' => (bool) pp_config()['configured']]);
    }

    if ($action === 'products' || $action === 'product') {
        $category = pp_string($_GET, 'categoria');
        $query = pp_string($_GET, 'q');
        $sort = pp_string($_GET, 'sort');
        if (strlen($query) > 150 || strlen($category) > 100) {
            pp_fail('A busca é muito longa.', 422);
        }
        if (!pp_config()['configured']) {
            require_once dirname(__DIR__) . '/includes/demo-products.php';
            $products = pp_demo_products();
            if ($action === 'product') {
                $id = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
                $products = array_values(array_filter($products, static fn (array $p): bool => $p['id'] === $id));
            } else {
                $products = array_values(array_filter($products, static function (array $product) use ($category, $query): bool {
                    $inCategory = $category === '' || $category === 'todos' || $category === (string) $product['categoria_id'] || $category === $product['categoria'];
                    $haystack = $product['nome'] . ' ' . $product['descricao'];
                    $matchesQuery = $query === '' || (function_exists('mb_stripos') ? mb_stripos($haystack, $query, 0, 'UTF-8') !== false : stripos($haystack, $query) !== false);
                    return $inCategory && $matchesQuery;
                }));
                usort($products, static function (array $a, array $b) use ($sort): int {
                    return match ($sort) {
                        'preco_asc', 'price_asc' => $a['preco'] <=> $b['preco'],
                        'preco_desc', 'price_desc' => $b['preco'] <=> $a['preco'],
                        'nome' => strcasecmp($a['nome'], $b['nome']),
                        default => ($b['destaque'] <=> $a['destaque']) ?: ($a['id'] <=> $b['id']),
                    };
                });
            }
        } else {
            $sql = 'SELECT p.*, c.nome AS categoria FROM produtos p JOIN categorias c ON c.id = p.categoria_id WHERE 1=1';
            $params = [];
            if ($action === 'product') {
                $sql .= ' AND p.id = ?';
                $params[] = filter_var($_GET['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) ?: 0;
            } else {
                if ($category !== '' && $category !== 'todos') {
                    $sql .= ctype_digit($category) ? ' AND p.categoria_id = ?' : ' AND c.nome = ?';
                    $params[] = $category;
                }
                if ($query !== '') {
                    $sql .= ' AND (p.nome LIKE ? OR p.descricao LIKE ?)';
                    $params[] = '%' . $query . '%';
                    $params[] = '%' . $query . '%';
                }
                $sql .= match ($sort) {
                    'preco_asc', 'price_asc' => ' ORDER BY p.preco ASC, p.id ASC',
                    'preco_desc', 'price_desc' => ' ORDER BY p.preco DESC, p.id ASC',
                    'nome' => ' ORDER BY p.nome ASC',
                    default => ' ORDER BY p.destaque DESC, p.id ASC',
                };
            }
            $statement = pp_db()->prepare($sql);
            $statement->execute($params);
            $products = array_map('pp_product_types', $statement->fetchAll());
        }
        if ($action === 'product') {
            if (!$products) {
                pp_fail('Não encontramos esse produto.', 404);
            }
            pp_json(['ok' => true, 'product' => $products[0]]);
        }
        pp_json(['ok' => true, 'products' => $products, 'demo' => !pp_config()['configured']]);
    }

    if ($action === 'register') {
        $db = pp_db();
        [$name, $phone, $address] = pp_validate_profile($input, true);
        $email = strtolower(pp_string($input, 'email'));
        $password = is_string($input['senha'] ?? null) ? $input['senha'] : '';
        if (strlen($password) < 8 || strlen($password) > 72 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[^A-Za-z0-9\s]/', $password)) {
            pp_fail('Escolha uma senha mais forte.', 422, ['senha' => 'Use 8 a 72 caracteres, com maiúscula, minúscula, número e símbolo.']);
        }
        $statement = $db->prepare('INSERT INTO usuarios (nome, email, senha_hash, telefone, endereco) VALUES (?, ?, ?, ?, ?)');
        try {
            $statement->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $phone, $address]);
        } catch (PDOException $exception) {
            if (($exception->errorInfo[1] ?? 0) === 1062) {
                pp_fail('Este e-mail já tem uma conta. Entre para continuar.', 409, ['email' => 'E-mail já cadastrado.']);
            }
            throw $exception;
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $db->lastInsertId();
        unset($_SESSION['login_failures']);
        pp_json(['ok' => true, 'message' => 'Sua conta está pronta. Que bom ter você por aqui!', 'user' => pp_user(), 'csrf' => $_SESSION['csrf']], 201);
    }

    if ($action === 'login') {
        $db = pp_db();
        $failures = array_values(array_filter($_SESSION['login_failures'] ?? [], static fn (int $time): bool => $time > time() - 900));
        if (count($failures) >= 8) {
            header('Retry-After: 900');
            pp_fail('Muitas tentativas. Aguarde 15 minutos antes de tentar novamente.', 429);
        }
        $email = strtolower(pp_string($input, 'email'));
        $password = is_string($input['senha'] ?? null) ? $input['senha'] : '';
        $statement = $db->prepare('SELECT id, senha_hash FROM usuarios WHERE email = ?');
        $statement->execute([substr($email, 0, 254)]);
        $row = $statement->fetch();
        $dummyHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
        $validPassword = strlen($password) <= 72 && password_verify($password, $row['senha_hash'] ?? $dummyHash);
        if (!$row || !$validPassword || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $failures[] = time();
            $_SESSION['login_failures'] = $failures;
            pp_fail('E-mail ou senha incorretos. Confira e tente novamente.', 401);
        }
        if (password_needs_rehash($row['senha_hash'], PASSWORD_DEFAULT)) {
            $statement = $db->prepare('UPDATE usuarios SET senha_hash = ? WHERE id = ?');
            $statement->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int) $row['id'];
        unset($_SESSION['login_failures']);
        pp_json(['ok' => true, 'message' => 'Que bom te ver de novo!', 'user' => pp_user(), 'csrf' => $_SESSION['csrf']]);
    }

    if ($action === 'logout') {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
        pp_json(['ok' => true, 'message' => 'Você saiu da sua conta.', 'csrf' => $_SESSION['csrf']]);
    }

    if ($action === 'profile') {
        $user = pp_require_user();
        [$name, $phone, $address] = pp_validate_profile($input);
        $statement = pp_db()->prepare('UPDATE usuarios SET nome = ?, telefone = ?, endereco = ? WHERE id = ?');
        $statement->execute([$name, $phone, $address, $user['id']]);
        pp_json(['ok' => true, 'message' => 'Seus dados foram atualizados.', 'user' => pp_user()]);
    }

    if ($action === 'account') {
        $user = pp_require_user();
        $statement = pp_db()->prepare('SELECT id, data, status, subtotal, desconto, frete, total, forma_pagamento, endereco, request_id FROM pedidos WHERE usuario_id = ? ORDER BY data DESC, id DESC LIMIT 50');
        $statement->execute([$user['id']]);
        $orders = $statement->fetchAll();
        $itemsByOrder = [];
        if ($orders) {
            $ids = array_column($orders, 'id');
            $statement = pp_db()->prepare('SELECT pedido_id, produto_id, produto_nome AS nome, quantidade, preco_unitario FROM itens_pedido WHERE pedido_id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id');
            $statement->execute($ids);
            foreach ($statement->fetchAll() as $item) {
                $orderId = $item['pedido_id'];
                unset($item['pedido_id']);
                $item['produto_id'] = (int) $item['produto_id'];
                $item['quantidade'] = (int) $item['quantidade'];
                $item['preco_unitario'] = (float) $item['preco_unitario'];
                $itemsByOrder[$orderId][] = $item;
            }
        }
        foreach ($orders as &$order) {
            $order = array_merge($order, pp_order_response($order));
            $order['items'] = $itemsByOrder[$order['id']] ?? [];
        }
        unset($order);
        $statement = pp_db()->prepare('SELECT id, servico, pet_nome, data_hora, status, observacoes FROM agendamentos WHERE usuario_id = ? ORDER BY data_hora DESC LIMIT 50');
        $statement->execute([$user['id']]);
        $appointments = $statement->fetchAll();
        foreach ($appointments as &$appointment) {
            $appointment['id'] = (int) $appointment['id'];
        }
        unset($appointment);
        pp_json(['ok' => true, 'user' => $user, 'orders' => $orders, 'appointments' => $appointments]);
    }

    if ($action === 'checkout') {
        $user = pp_require_user();
        $items = $input['items'] ?? null;
        $address = pp_string($input, 'endereco');
        $payment = pp_string($input, 'forma_pagamento');
        $coupon = strtoupper(pp_string($input, 'cupom'));
        $requestId = pp_string($input, 'request_id');
        if (!is_array($items) || !array_is_list($items) || !$items || count($items) > 100) {
            pp_fail('Adicione produtos ao carrinho antes de finalizar.');
        }
        if (pp_length($address) < 10 || pp_length($address) > 1000) {
            pp_fail('Informe o endereço completo de entrega.', 422, ['endereco' => 'Use entre 10 e 1.000 caracteres.']);
        }
        if (!in_array($payment, ['pix', 'cartao', 'boleto'], true)) {
            pp_fail('Escolha uma das formas de pagamento demonstrativas.', 422, ['forma_pagamento' => 'Forma de pagamento inválida.']);
        }
        if (!preg_match('/^[a-zA-Z0-9_-]{16,64}$/', $requestId)) {
            pp_fail('A identificação do pedido expirou. Atualize a página e tente novamente.', 422);
        }
        if ($coupon !== '' && $coupon !== 'PRIMEIROPASSEIO') {
            pp_fail('Esse cupom não foi encontrado.', 422, ['cupom' => 'Cupom inválido.']);
        }
        $quantities = [];
        foreach ($items as $item) {
            if (!is_array($item) || !isset($item['id'], $item['quantidade']) || !is_int($item['id']) || !is_int($item['quantidade']) || $item['id'] < 1 || $item['quantidade'] < 1 || $item['quantidade'] > 99) {
                pp_fail('Há um item inválido no carrinho. Atualize a página e confira as quantidades.');
            }
            $quantities[$item['id']] = ($quantities[$item['id']] ?? 0) + $item['quantidade'];
            if ($quantities[$item['id']] > 99) {
                pp_fail('O limite é de 99 unidades por produto.');
            }
        }
        ksort($quantities, SORT_NUMERIC);
        $db = pp_db();
        $db->beginTransaction();
        try {
            // Serializing this customer's orders also protects the first-order coupon.
            $statement = $db->prepare('SELECT id FROM usuarios WHERE id = ? FOR UPDATE');
            $statement->execute([$user['id']]);
            $statement = $db->prepare('SELECT id, status, subtotal, desconto, frete, total FROM pedidos WHERE usuario_id = ? AND request_id = ?');
            $statement->execute([$user['id'], $requestId]);
            $existingOrder = $statement->fetch();
            if ($existingOrder) {
                $db->commit();
                pp_json(['ok' => true, 'message' => 'Seu pedido já foi registrado.', 'order' => pp_order_response($existingOrder)]);
            }
            if ($coupon !== '') {
                $statement = $db->prepare('SELECT id FROM pedidos WHERE usuario_id = ? LIMIT 1');
                $statement->execute([$user['id']]);
                if ($statement->fetch()) {
                    $db->rollBack();
                    pp_fail('O cupom PRIMEIROPASSEIO é válido somente no primeiro pedido.', 422, ['cupom' => 'Cupom exclusivo para o primeiro pedido.']);
                }
            }
            $ids = array_keys($quantities);
            $statement = $db->prepare('SELECT id, nome, preco, estoque FROM produtos WHERE id IN (' . implode(',', array_fill(0, count($ids), '?')) . ') ORDER BY id FOR UPDATE');
            $statement->execute($ids);
            $products = $statement->fetchAll();
            if (count($products) !== count($ids)) {
                $db->rollBack();
                pp_fail('Um dos produtos não está mais disponível. Revise seu carrinho.', 409);
            }
            $subtotal = 0;
            foreach ($products as $product) {
                $quantity = $quantities[$product['id']];
                if ((int) $product['estoque'] < $quantity) {
                    $db->rollBack();
                    pp_fail('Estoque insuficiente para ' . $product['nome'] . '. Disponível: ' . $product['estoque'] . '.', 409);
                }
                $subtotal += pp_cents((string) $product['preco']) * $quantity;
            }
            // Round ten percent to the nearest cent, with halves rounded upward.
            $discount = $coupon === '' ? 0 : intdiv($subtotal + 5, 10);
            $shipping = $subtotal - $discount >= 14900 ? 0 : 1490;
            $total = $subtotal - $discount + $shipping;
            $statement = $db->prepare('INSERT INTO pedidos (usuario_id, status, subtotal, desconto, frete, total, endereco, forma_pagamento, cupom, request_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $statement->execute([$user['id'], 'Confirmado (simulação)', pp_decimal($subtotal), pp_decimal($discount), pp_decimal($shipping), pp_decimal($total), $address, $payment, $coupon ?: null, $requestId]);
            $orderId = (int) $db->lastInsertId();
            $insertItem = $db->prepare('INSERT INTO itens_pedido (pedido_id, produto_id, produto_nome, quantidade, preco_unitario) VALUES (?, ?, ?, ?, ?)');
            $updateStock = $db->prepare('UPDATE produtos SET estoque = estoque - ? WHERE id = ?');
            foreach ($products as $product) {
                $quantity = $quantities[$product['id']];
                $insertItem->execute([$orderId, $product['id'], $product['nome'], $quantity, $product['preco']]);
                $updateStock->execute([$quantity, $product['id']]);
            }
            $statement = $db->prepare('UPDATE usuarios SET endereco = ? WHERE id = ?');
            $statement->execute([$address, $user['id']]);
            $db->commit();
        } catch (Throwable $exception) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }
            throw $exception;
        }
        pp_json(['ok' => true, 'message' => 'Pedido demonstrativo confirmado! Nenhum pagamento foi cobrado.', 'order' => ['id' => $orderId, 'status' => 'Confirmado (simulação)', 'subtotal' => $subtotal / 100, 'desconto' => $discount / 100, 'frete' => $shipping / 100, 'total' => $total / 100]], 201);
    }

    if ($action === 'appointment') {
        $user = pp_require_user();
        $service = pp_string($input, 'servico');
        $petName = pp_string($input, 'pet_nome');
        $dateInput = pp_string($input, 'data_hora');
        $notes = pp_string($input, 'observacoes');
        $errors = [];
        if (!in_array($service, ['Banho completo', 'Banho e tosa', 'Consulta veterinária'], true)) {
            $errors['servico'] = 'Escolha um dos serviços disponíveis.';
        }
        if (pp_length($petName) < 1 || pp_length($petName) > 80) {
            $errors['pet_nome'] = 'Informe o nome do pet (até 80 caracteres).';
        }
        if (pp_length($notes) > 1000) {
            $errors['observacoes'] = 'Use até 1.000 caracteres nas observações.';
        }
        $date = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $dateInput);
        $dateErrors = DateTimeImmutable::getLastErrors();
        $now = new DateTimeImmutable();
        if (!$date || ($dateErrors !== false && ($dateErrors['warning_count'] || $dateErrors['error_count'])) || $date->format('Y-m-d\TH:i') !== $dateInput) {
            $errors['data_hora'] = 'Escolha uma data e um horário válidos.';
        } elseif ($date <= $now || $date > $now->modify('+90 days')) {
            $errors['data_hora'] = 'Escolha um horário futuro nos próximos 90 dias.';
        } elseif ($date->format('N') === '7' || (int) $date->format('H') < 9 || (int) $date->format('H') > 17 || $date->format('i') !== '00') {
            $errors['data_hora'] = 'Atendemos de segunda a sábado, das 09h às 17h, em horários de hora em hora.';
        }
        if ($errors) {
            pp_fail('Confira os dados do agendamento.', 422, $errors);
        }
        $statement = pp_db()->prepare('INSERT INTO agendamentos (usuario_id, servico, pet_nome, data_hora, status, observacoes) VALUES (?, ?, ?, ?, ?, ?)');
        try {
            $statement->execute([$user['id'], $service, $petName, $date->format('Y-m-d H:i:s'), 'Confirmado', $notes]);
        } catch (PDOException $exception) {
            if (($exception->errorInfo[1] ?? 0) === 1062) {
                pp_fail('Esse horário acabou de ser reservado. Escolha outro para o seu pet.', 409, ['data_hora' => 'Horário indisponível.']);
            }
            throw $exception;
        }
        pp_json(['ok' => true, 'message' => 'Agendamento confirmado. Seu pet já tem um encontro com o cuidado!', 'appointment' => ['id' => (int) pp_db()->lastInsertId(), 'servico' => $service, 'pet_nome' => $petName, 'data_hora' => $date->format('Y-m-d H:i:s'), 'status' => 'Confirmado']], 201);
    }

    if ($action === 'contact') {
        $db = pp_db();
        $name = pp_string($input, 'nome');
        $email = strtolower(pp_string($input, 'email'));
        $subject = pp_string($input, 'assunto');
        $message = pp_string($input, 'mensagem');
        $errors = [];
        if (pp_length($name) < 2 || pp_length($name) > 100) {
            $errors['nome'] = 'Informe seu nome (2 a 100 caracteres).';
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) {
            $errors['email'] = 'Informe um e-mail válido.';
        }
        if (pp_length($subject) < 2 || pp_length($subject) > 150) {
            $errors['assunto'] = 'Informe o assunto (2 a 150 caracteres).';
        }
        if (pp_length($message) < 10 || pp_length($message) > 5000) {
            $errors['mensagem'] = 'Conte um pouco mais (10 a 5.000 caracteres).';
        }
        if ($errors) {
            pp_fail('Confira os campos da mensagem.', 422, $errors);
        }
        if (isset($_SESSION['last_contact']) && $_SESSION['last_contact'] > time() - 60) {
            header('Retry-After: 60');
            pp_fail('Sua mensagem anterior já foi recebida. Aguarde um minuto antes de enviar outra.', 429);
        }
        $statement = $db->prepare('INSERT INTO mensagens (nome, email, assunto, mensagem) VALUES (?, ?, ?, ?)');
        $statement->execute([$name, $email, $subject, $message]);
        $_SESSION['last_contact'] = time();
        pp_json(['ok' => true, 'message' => 'Mensagem registrada com carinho! Nesta demonstração, ela fica salva no banco; não há envio de e-mail.'], 201);
    }
} catch (PDOException $exception) {
    error_log('Pata & Prosa database error: ' . $exception->getMessage());
    pp_fail('Não foi possível acessar o banco de dados agora. Confira a configuração local e a importação do schema.sql.', 503);
} catch (Throwable $exception) {
    error_log('Pata & Prosa API error: ' . $exception->getMessage());
    pp_fail('Algo inesperado aconteceu. Tente novamente em instantes.', 500);
}
