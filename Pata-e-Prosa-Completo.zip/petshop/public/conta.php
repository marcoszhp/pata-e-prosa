<?php require __DIR__.'/../includes/layout.php'; page_start('Seu cantinho', 'account'); ?>
<section class="page-intro"><div class="container"><span class="eyebrow">BEM-VINDO AO SEU CANTINHO</span><h1 id="account-greeting">Sua família, nossos cuidados.</h1><p>Seus pedidos, próximos cuidados e dados, pertinho de você.</p></div></section><section class="section"><div class="container" id="account-content"><p class="loading">Preparando seu cantinho…</p></div></section>
<?php page_end(); ?>
