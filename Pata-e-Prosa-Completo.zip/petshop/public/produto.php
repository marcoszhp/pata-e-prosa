<?php require __DIR__.'/../includes/layout.php'; page_start('Um mimo para seu pet', 'product'); ?>
<div class="container"><div class="breadcrumbs"><a href="index.php">Início</a><span>/</span><a href="catalogo.php">Nossos produtos</a><span>/</span><span id="product-breadcrumb">Seu próximo favorito</span></div><div id="product-detail" class="section"><p class="loading">Preparando os detalhes desse mimo…</p></div></div>
<?php page_end(); ?>
