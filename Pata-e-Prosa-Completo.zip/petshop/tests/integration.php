<?php
declare(strict_types=1);

// CLI-only, real HTTP + MySQL integration tests. Never point these at production.
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}
date_default_timezone_set('America/Sao_Paulo');
$database = getenv('DB_NAME') ?: '';
$baseUrl = rtrim($argv[1] ?? 'http://127.0.0.1:8086/public', '/');
$keepFixtures = in_array('--keep-fixtures', $argv, true);
if (!preg_match('/^[a-zA-Z0-9_]+_test$/', $database) || !in_array(parse_url($baseUrl, PHP_URL_HOST), ['localhost', '127.0.0.1'], true)) {
    fwrite(STDERR, "Use um banco exclusivo com nome terminado em _test e uma URL HTTP local.\n");
    exit(1);
}
if (!extension_loaded('curl')) {
    fwrite(STDERR, "Ative a extensão curl do PHP para executar as verificações HTTP.\n");
    exit(1);
}

final class ApiClient
{
    private CurlHandle $curl;
    public string $csrf = '';

    public function __construct(private string $baseUrl)
    {
        $this->curl = curl_init();
        curl_setopt_array($this->curl, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEFILE => '', CURLOPT_TIMEOUT => 15]);
    }

    public function request(string $action, ?array $body = null, array $query = [], ?string $token = null): array
    {
        curl_setopt_array($this->curl, [
            CURLOPT_URL => $this->baseUrl . '/api.php?' . http_build_query(['action' => $action] + $query),
            CURLOPT_CUSTOMREQUEST => $body === null ? 'GET' : 'POST',
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-CSRF-Token: ' . ($token ?? $this->csrf)],
            CURLOPT_POSTFIELDS => $body === null ? null : json_encode($body, JSON_THROW_ON_ERROR),
        ]);
        $raw = curl_exec($this->curl);
        if ($raw === false) {
            throw new RuntimeException(curl_error($this->curl));
        }
        $json = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        if (isset($json['csrf'])) {
            $this->csrf = $json['csrf'];
        }
        return ['status' => curl_getinfo($this->curl, CURLINFO_HTTP_CODE), 'data' => $json];
    }
}

$assertions = 0;
function verify(bool $condition, string $description): void
{
    global $assertions;
    if (!$condition) {
        throw new RuntimeException('FALHOU: ' . $description);
    }
    $assertions++;
    echo "OK: $description\n";
}

$pdo = new PDO(
    sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', getenv('DB_HOST') ?: '127.0.0.1', getenv('DB_PORT') ?: '3306', $database),
    getenv('DB_USER') ?: 'root',
    getenv('DB_PASSWORD') ?: '',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
);
$nonce = bin2hex(random_bytes(8));
$email = 'integration-' . $nonce . '@example.test';
$otherEmail = 'other-' . $nonce . '@example.test';
$fixtureIds = [];
$userIds = [];
$exitCode = 0;
try {
    $insert = $pdo->prepare('INSERT INTO produtos (nome, descricao, preco, categoria_id, imagem_url, estoque, destaque) VALUES (?, ?, ?, 1, ?, ?, 0)');
    foreach ([['Fixture-' . $nonce, '100.00', 5], ['Sem-estoque-' . $nonce, '20.00', 0]] as [$name, $price, $stock]) {
        $insert->execute([$name, 'Produto exclusivo da verificação automatizada.', $price, '../assets/images/food-salmon.svg', $stock]);
        $fixtureIds[] = (int) $pdo->lastInsertId();
    }
    [$productId, $emptyProductId] = $fixtureIds;
    $client = new ApiClient($baseUrl);
    $probe = $client->request('product', null, ['id' => $productId]);
    verify($probe['status'] === 200 && ($probe['data']['product']['nome'] ?? '') === 'Fixture-' . $nonce, 'API utiliza o banco isolado de teste');
    $session = $client->request('session');
    verify($session['status'] === 200 && $session['data']['configured'] && strlen($client->csrf) === 64, 'Sessão e token de segurança criados');
    verify($client->request('account')['status'] === 401, 'Área do cliente exige autenticação');
    $profile = ['nome' => 'Ana Teste', 'email' => $email, 'senha' => 'PataTeste!2026', 'telefone' => '(11) 99999-1234', 'endereco' => 'Rua de Teste, 123, São Paulo'];
    verify($client->request('register', $profile, [], '')['status'] === 419, 'Cadastro rejeita token CSRF ausente');
    verify($client->request('register', array_replace($profile, ['senha' => 'fraca']))['status'] === 422, 'Cadastro rejeita senha fraca');
    verify($client->request('register', array_replace($profile, ['email' => 'email-invalido']))['status'] === 422, 'Cadastro rejeita e-mail inválido');
    $registered = $client->request('register', $profile);
    verify($registered['status'] === 201, 'Cadastro válido grava a conta');
    $userIds[] = (int) $registered['data']['user']['id'];
    $statement = $pdo->prepare('SELECT senha_hash FROM usuarios WHERE id = ?');
    $statement->execute([$userIds[0]]);
    $hash = $statement->fetchColumn();
    verify(is_string($hash) && $hash !== $profile['senha'] && password_verify($profile['senha'], $hash), 'Senha é armazenada como hash verificável');
    verify($client->request('register', $profile)['status'] === 409, 'E-mail duplicado é rejeitado');
    verify($client->request('session')['data']['user']['id'] === $userIds[0], 'Sessão autenticada permanece entre requisições');
    verify($client->request('profile', ['nome' => 'Ana e Bolota', 'telefone' => '(11) 99999-4321', 'endereco' => $profile['endereco']])['status'] === 200, 'Cliente pode editar seus dados');
    verify($client->request('account')['data']['user']['nome'] === 'Ana e Bolota', 'Alteração de perfil persiste no banco');
    $checkout = ['items' => [['id' => $productId, 'quantidade' => 2, 'preco' => 0.01]], 'endereco' => $profile['endereco'], 'forma_pagamento' => 'pix', 'cupom' => 'PRIMEIROPASSEIO', 'request_id' => 'test_' . $nonce, 'total' => 0.02];
    $order = $client->request('checkout', $checkout);
    verify($order['status'] === 201, 'Checkout grava pedido e itens');
    $savedOrders = $client->request('account')['data']['orders'];
    verify(count($savedOrders) === 1 && ($savedOrders[0]['request_id'] ?? '') === $checkout['request_id'], 'Histórico devolve o identificador usado para recuperar o pedido');
    verify((float) $order['data']['order']['subtotal'] === 200.0 && (float) $order['data']['order']['desconto'] === 20.0 && (float) $order['data']['order']['frete'] === 0.0 && (float) $order['data']['order']['total'] === 180.0, 'Preço adulterado é ignorado e cupom/frete são calculados no servidor');
    $stock = fn () => (int) $pdo->query('SELECT estoque FROM produtos WHERE id = ' . $productId)->fetchColumn();
    verify($stock() === 3, 'Estoque é reduzido pela quantidade comprada');
    $repeated = $client->request('checkout', $checkout);
    verify($repeated['status'] === 200 && $repeated['data']['order']['id'] === $order['data']['order']['id'] && $stock() === 3, 'Repetir o mesmo pedido não duplica cobrança simulada nem baixa de estoque');
    $nextCheckout = array_replace($checkout, ['request_id' => 'next_' . $nonce]);
    verify($client->request('checkout', $nextCheckout)['status'] === 422, 'Cupom de primeiro pedido não pode ser reutilizado');
    $insufficient = array_replace($nextCheckout, ['cupom' => '', 'items' => [['id' => $productId, 'quantidade' => 1], ['id' => $emptyProductId, 'quantidade' => 1]]]);
    verify($client->request('checkout', $insufficient)['status'] === 409 && $stock() === 3, 'Falta de estoque reverte o pedido inteiro');
    verify(count($client->request('account')['data']['orders']) === 1, 'Pedido rejeitado não deixa registros parciais');
    $paidShipping = $client->request('checkout', array_replace($nextCheckout, ['cupom' => '', 'items' => [['id' => $productId, 'quantidade' => 1]]]));
    verify($paidShipping['status'] === 201 && (float) $paidShipping['data']['order']['total'] === 114.9 && (float) $paidShipping['data']['order']['frete'] === 14.9, 'Frete de R$ 14,90 aplicado abaixo do limite');
    verify($client->request('checkout', array_replace($nextCheckout, ['cupom' => '', 'request_id' => 'bad_' . $nonce, 'items' => [['id' => $productId, 'quantidade' => -1]]]))['status'] === 422, 'Quantidade negativa é rejeitada');
    $date = (new DateTimeImmutable('tomorrow'))->setTime(10, 0);
    do {
        if ($date->format('N') === '7') { $date = $date->modify('+1 day'); }
        $slot = $pdo->prepare('SELECT COUNT(*) FROM agendamentos WHERE data_hora = ?');
        $slot->execute([$date->format('Y-m-d H:i:s')]);
        $occupied = (int) $slot->fetchColumn() > 0;
        if ($occupied) { $date = $date->modify('+1 day'); }
    } while ($occupied);
    $appointment = ['servico' => 'Banho completo', 'pet_nome' => 'Bolota', 'data_hora' => $date->format('Y-m-d\TH:i'), 'observacoes' => 'Teste de integração.'];
    verify($client->request('appointment', array_replace($appointment, ['data_hora' => '2020-01-01T10:00']))['status'] === 422, 'Agendamento em data passada é rejeitado');
    verify($client->request('appointment', array_replace($appointment, ['data_hora' => $date->format('Y-m-d') . 'T22:00']))['status'] === 422, 'Agendamento fora do horário é rejeitado');
    verify($client->request('appointment', $appointment)['status'] === 201, 'Agendamento válido é salvo');
    verify($client->request('appointment', $appointment)['status'] === 409, 'Horário duplicado é bloqueado');
    verify(count($client->request('account')['data']['appointments']) === 1, 'Agendamento aparece na área do cliente');
    $contact = ['nome' => 'Ana Teste', 'email' => $email, 'assunto' => 'Teste de contato', 'mensagem' => 'Gostaria de saber mais sobre os serviços.'];
    verify($client->request('contact', array_replace($contact, ['mensagem' => 'oi']))['status'] === 422, 'Contato valida o tamanho da mensagem');
    verify($client->request('contact', $contact)['status'] === 201, 'Contato válido é registrado');
    $statement = $pdo->prepare('SELECT COUNT(*) FROM mensagens WHERE email = ?');
    $statement->execute([$email]);
    verify((int) $statement->fetchColumn() === 1, 'Mensagem do contato existe no banco');
    verify($client->request('contact', $contact)['status'] === 429, 'Envio repetido de contato tem limite');
    $other = new ApiClient($baseUrl);
    $other->request('session');
    $newUser = $other->request('register', array_replace($profile, ['email' => $otherEmail]));
    verify($newUser['status'] === 201, 'Segundo cliente cadastrado para validar privacidade');
    $userIds[] = (int) $newUser['data']['user']['id'];
    $privateAccount = $other->request('account');
    verify($privateAccount['data']['orders'] === [] && $privateAccount['data']['appointments'] === [], 'Um cliente não vê pedidos ou agendamentos de outro');
    $oldToken = $client->csrf;
    verify($client->request('logout', [])['status'] === 200, 'Logout encerra a autenticação');
    verify($client->request('account')['status'] === 401 && $oldToken !== $client->csrf, 'Logout invalida autenticação e renova o token CSRF');
    verify($client->request('login', ['email' => "' OR 1=1 --", 'senha' => 'senha-errada'])['status'] === 401, 'Tentativa de injeção não autentica');
    verify($client->request('login', ['email' => $email, 'senha' => 'senha-errada'])['status'] === 401, 'Senha incorreta é rejeitada');
    verify($client->request('login', ['email' => $email, 'senha' => $profile['senha']])['status'] === 200, 'Login por senha válida funciona após logout');
    verify(count($client->request('account')['data']['orders']) === 2, 'Histórico de pedidos persiste após novo login');
    echo "\n$assertions verificações de integração passaram.\n";
} catch (Throwable $error) {
    fwrite(STDERR, $error->getMessage() . "\n");
    $exitCode = 1;
} finally {
    if ($keepFixtures) {
        echo "Dados exclusivos desta execução preservados no banco de teste (--keep-fixtures).\n";
    } else {
    // Cleanup is limited to nonce-tagged accounts, messages and product fixtures.
    $lookup = $pdo->prepare('SELECT id FROM usuarios WHERE email IN (?, ?)');
    $lookup->execute([$email, $otherEmail]);
    $userIds = array_map('intval', $lookup->fetchAll(PDO::FETCH_COLUMN));
    foreach ($userIds as $userId) {
        $pdo->exec('DELETE FROM itens_pedido WHERE pedido_id IN (SELECT id FROM pedidos WHERE usuario_id = ' . $userId . ')');
        $pdo->exec('DELETE FROM pedidos WHERE usuario_id = ' . $userId);
        $pdo->exec('DELETE FROM agendamentos WHERE usuario_id = ' . $userId);
        $pdo->exec('DELETE FROM usuarios WHERE id = ' . $userId);
    }
    $deleteMessage = $pdo->prepare('DELETE FROM mensagens WHERE email = ?');
    $deleteMessage->execute([$email]);
    foreach ($fixtureIds as $fixtureId) { $pdo->exec('DELETE FROM produtos WHERE id = ' . $fixtureId); }
    }
}
exit($exitCode);
