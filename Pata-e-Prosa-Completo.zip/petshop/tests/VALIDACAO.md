# Validação — Pata & Prosa

Data: 24/09/2026.

## Ambiente e resultado

O projeto foi executado com PHP 8.3.35 e MariaDB 11.4.8 reais em ambiente local Windows. O preview utiliza `127.0.0.1:8085` com o banco `pata_prosa`; as verificações de gravação usam `127.0.0.1:8086` com o banco isolado `pata_prosa_test`. O banco escuta somente em `127.0.0.1:3307`.

A suíte `tests/integration.php` aprovou inicialmente 38 verificações. Após a inclusão do identificador do pedido no histórico, uma nova execução aprovou **39 verificações**, incluindo a correspondência de `order.request_id` com o identificador enviado no checkout. A última execução utilizou `--keep-fixtures`, preservando seus dados no banco de teste. A conta usada na revisão visual também foi preservada.

## Backend e banco de dados

As verificações automatizadas cobriram:

- Sessão PHP, criação e renovação do token CSRF, rejeição de gravação sem token e proteção da área do cliente.
- Cadastro válido, rejeição de senha fraca/e-mail inválido/e-mail duplicado, armazenamento da senha como hash e login após logout.
- Persistência dos dados do perfil e separação de pedidos e agendamentos entre clientes.
- Pedido e itens gravados, valores recalculados no servidor, rejeição de preço adulterado no corpo da requisição, desconto de primeiro pedido e frete.
- Redução correta do estoque, repetição do identificador sem criar outra compra, recuperação desse identificador pelo histórico e rejeição de reutilização do cupom.
- Reversão integral do pedido quando um item está sem estoque, ausência de pedido parcial e rejeição de quantidade negativa.
- Rejeição de data passada/horário fora do atendimento, gravação do agendamento, bloqueio de horário duplicado e exibição na área do cliente.
- Validação do contato, persistência da mensagem e limitação de envio repetido.
- Rejeição de senha incorreta e de tentativa de injeção SQL no login.

Todos os 19 arquivos PHP existentes na verificação de sintaxe passaram no lint. As páginas públicas e o catálogo da API responderam com HTTP 200. O roteador local respondeu com HTTP 404 para tentativas de acessar arquivos privados de configuração e do runtime.

## Interface e fluxo de compra

Os seguintes cenários foram verificados no navegador:

| Cenário | Resultado observado |
| --- | --- |
| Filtro de brinquedos | O catálogo exibiu 3 produtos da categoria. |
| Ordenação | O seletor de ordenação foi acionado na interface. |
| Produto e quantidade | Duas unidades de Corda Arco-íris produziram subtotal de R$ 59,80. |
| Carrinho | Frete de R$ 14,90 e total de R$ 74,70 antes do cupom. |
| Cadastro | A conta sintética `visual.qa.20260924@example.test` foi cadastrada no ambiente de testes. |
| Cupom | O desconto foi de R$ 5,98 e o total final de R$ 68,72. |
| Checkout e histórico | O pedido demonstrativo `00005` foi concluído e persistiu na área do cliente. |
| Perfil | A alteração do telefone foi salva. |
| Agendamento | Reserva para o pet “Bento de Teste”, em 02/10/2026 às 10h, confirmada. |
| Contato | O envio apresentou o diálogo estilizado de sucesso e a mensagem foi gravada. |

Nenhuma senha da conta de revisão está registrada neste relatório.

## Responsividade e navegador

Foram inspecionadas capturas da home e do catálogo com largura de 390 px. Também foram verificadas 7 páginas em 320 px: não houve transbordamento horizontal nem imagens quebradas nos cenários inspecionados. O navegador não registrou erros durante os fluxos verificados.

Essas verificações cobrem os cenários e tamanhos observados; não substituem uma matriz completa de navegadores, dispositivos, acessibilidade ou testes de carga.

## Limites da validação

- O Apache do XAMPP/WAMP e o MySQL Oracle não foram executados nesta máquina; sua instalação está documentada no README. A execução real utilizou o servidor PHP embutido e MariaDB.
- Pagamento, frete e marca são demonstrativos. Nenhum gateway, cobrança, entrega ou envio de e-mail externo foi testado ou integrado.
- Os servidores de preview permaneceram ativos ao concluir este relatório. Nenhuma conta existente foi removida durante a verificação final.
- O banco de testes contém dados sintéticos de revisão; eles não integram os dados iniciais de `sql/schema.sql`.
