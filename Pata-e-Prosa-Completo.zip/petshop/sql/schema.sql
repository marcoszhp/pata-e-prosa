-- Pata & Prosa • MySQL 5.7+/8+ or MariaDB 10.4+
-- Import once with phpMyAdmin or: mysql -u root -p < sql/schema.sql
-- Existing records are preserved if this setup is imported again.
CREATE DATABASE IF NOT EXISTS pata_prosa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pata_prosa;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(254) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    telefone VARCHAR(30) NOT NULL DEFAULT '',
    endereco TEXT NOT NULL,
    data_cadastro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY usuarios_email_unique (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categorias (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY categorias_nome_unique (nome)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produtos (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT NOT NULL,
    preco DECIMAL(10,2) UNSIGNED NOT NULL,
    preco_anterior DECIMAL(10,2) UNSIGNED NULL,
    categoria_id INT UNSIGNED NOT NULL,
    imagem_url VARCHAR(500) NOT NULL,
    estoque INT UNSIGNED NOT NULL DEFAULT 0,
    destaque TINYINT(1) NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY produtos_categoria_index (categoria_id),
    CONSTRAINT produtos_categoria_fk FOREIGN KEY (categoria_id) REFERENCES categorias (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedidos (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id INT UNSIGNED NOT NULL,
    data TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(40) NOT NULL DEFAULT 'Confirmado (simulação)',
    subtotal DECIMAL(12,2) UNSIGNED NOT NULL,
    desconto DECIMAL(12,2) UNSIGNED NOT NULL DEFAULT 0.00,
    frete DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0.00,
    total DECIMAL(12,2) UNSIGNED NOT NULL,
    endereco TEXT NOT NULL,
    forma_pagamento VARCHAR(20) NOT NULL,
    cupom VARCHAR(40) NULL,
    request_id VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY pedidos_idempotency_unique (usuario_id, request_id),
    KEY pedidos_usuario_data_index (usuario_id, data),
    CONSTRAINT pedidos_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS itens_pedido (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    pedido_id INT UNSIGNED NOT NULL,
    produto_id INT UNSIGNED NOT NULL,
    produto_nome VARCHAR(150) NOT NULL,
    quantidade INT UNSIGNED NOT NULL,
    preco_unitario DECIMAL(10,2) UNSIGNED NOT NULL,
    PRIMARY KEY (id),
    KEY itens_pedido_pedido_index (pedido_id),
    KEY itens_pedido_produto_index (produto_id),
    CONSTRAINT itens_pedido_pedido_fk FOREIGN KEY (pedido_id) REFERENCES pedidos (id),
    CONSTRAINT itens_pedido_produto_fk FOREIGN KEY (produto_id) REFERENCES produtos (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS agendamentos (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    usuario_id INT UNSIGNED NOT NULL,
    servico VARCHAR(80) NOT NULL,
    pet_nome VARCHAR(80) NOT NULL,
    data_hora DATETIME NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Confirmado',
    observacoes TEXT NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    -- This example has one professional, so each time slot can be booked once.
    UNIQUE KEY agendamentos_horario_unique (data_hora),
    KEY agendamentos_usuario_index (usuario_id),
    CONSTRAINT agendamentos_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS mensagens (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(254) NOT NULL,
    assunto VARCHAR(150) NOT NULL,
    mensagem TEXT NOT NULL,
    criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT IGNORE INTO categorias (id, nome) VALUES
(1, 'Ração'), (2, 'Brinquedos'), (3, 'Higiene'), (4, 'Acessórios'), (5, 'Roupas');

-- Fictitious product illustrations: replace imagem_url with real licensed photos.
INSERT IGNORE INTO produtos (id, nome, descricao, preco, preco_anterior, categoria_id, imagem_url, estoque, destaque) VALUES
(1, 'Ração Natural Salmão & Arroz', 'Uma receita equilibrada para cães adultos, com salmão, arroz integral e muito sabor. Pacote de 2 kg. Produto fictício para demonstração.', 89.90, 109.90, 1, '../assets/images/food-salmon.svg', 40, 1),
(2, 'Ração Natural Frango & Abóbora', 'Comida cheia de cuidado para cães adultos de todos os portes. Frango, abóbora e ingredientes selecionados em um pacote de 2 kg. Produto fictício.', 79.90, NULL, 1, '../assets/images/food-chicken.svg', 35, 0),
(3, 'Corda Arco-íris', 'Uma corda resistente, colorida e macia para as brincadeiras favoritas do seu melhor amigo. Comprimento de 30 cm. Supervisione o uso.', 29.90, 39.90, 2, '../assets/images/toy-rope.svg', 60, 1),
(4, 'Bolinha Pula & Brinca', 'Textura divertida e tamanho ideal para buscar, correr e repetir. Borracha flexível, diâmetro de 7 cm. Brinquedo para cães; use com supervisão.', 24.90, NULL, 2, '../assets/images/toy-ball.svg', 50, 0),
(5, 'Shampoo Abraço de Aveia', 'Um banho com perfume suave e sensação de carinho. Shampoo demonstrativo para cães e gatos, com aveia, em frasco de 500 ml.', 34.90, NULL, 3, '../assets/images/shampoo.svg', 45, 1),
(6, 'Coleira Passeio Feliz', 'Passeios com cor e conforto. Coleira ajustável de nylon com fecho prático e argola metálica, tamanho M (30 a 45 cm). Cor: verde sálvia.', 49.90, 59.90, 4, '../assets/images/collar.svg', 28, 1),
(7, 'Caminha Nuvem de Algodão', 'O cantinho de descanso que abraça. Caminha macia com capa removível e base antiderrapante, 60 × 50 cm. Cor: areia.', 159.90, 189.90, 4, '../assets/images/bed.svg', 15, 0),
(8, 'Moletom Dias de Chamego', 'Para os dias fresquinhos, uma camada extra de aconchego. Moletom macio, tamanho M, com abertura para a guia. Cor: terracota.', 69.90, NULL, 5, '../assets/images/clothing.svg', 22, 0),
(9, 'Ração Gatos Jardim de Sabores', 'Receita fictícia de salmão para gatos adultos, em pacote de 1 kg. Grãos pequenos e uma combinação de sabores para o momento mais esperado do dia.', 54.90, NULL, 1, '../assets/images/food-salmon.svg', 32, 0),
(10, 'Kit Dupla Diversão', 'Duas bolinhas coloridas para multiplicar a brincadeira. Borracha flexível e textura macia, 6 cm cada. Sempre supervisione o pet durante o uso.', 39.90, 49.90, 2, '../assets/images/toy-ball.svg', 25, 0),
(11, 'Condicionador Pelo de Nuvem', 'O toque final do banho: condicionador demonstrativo para cães, com fragrância suave e embalagem de 500 ml. Aplique conforme orientações do fabricante.', 32.90, NULL, 3, '../assets/images/shampoo.svg', 30, 0),
(12, 'Suéter Tricot Caramelo', 'Um clássico para acompanhar os melhores cochilos. Suéter de malha flexível, tamanho P, para pets de 2 a 5 kg. Cor: caramelo.', 59.90, 74.90, 5, '../assets/images/clothing.svg', 18, 0);
