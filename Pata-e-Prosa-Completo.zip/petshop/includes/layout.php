<?php
declare(strict_types=1);
function page_start(string $title, string $page): void {
    $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $safePage = htmlspecialchars($page, ENT_QUOTES, 'UTF-8');
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#fc6a2b">
  <meta name="description" content="Pata & Prosa: produtos escolhidos com carinho, banho, tosa e cuidado veterinário. Tudo para uma vida boa de pet.">
  <title><?= $safeTitle ?> · Pata & Prosa</title>
  <link rel="icon" type="image/svg+xml" href="../assets/images/favicon.svg">
  <link rel="stylesheet" href="../assets/css/style.css">
  <script src="../assets/js/app.js" defer></script>
</head>
<body data-page="<?= $safePage ?>">
<a class="skip-link" href="#main">Pular para o conteúdo</a>
<svg class="svg-library" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
 <symbol id="i-paw" viewBox="0 0 24 24"><ellipse cx="5" cy="8" rx="2.6" ry="3.3" fill="currentColor" transform="rotate(-25 5 8)"/><ellipse cx="10" cy="4.8" rx="2.5" ry="3.3" fill="currentColor"/><ellipse cx="16" cy="5.8" rx="2.5" ry="3.3" fill="currentColor" transform="rotate(18 16 5.8)"/><ellipse cx="20" cy="11" rx="2.4" ry="3.1" fill="currentColor" transform="rotate(30 20 11)"/><path d="M5 19c-2-3 1-5 3-7s4-2 6 0 5 5 3 8c-2 3-4 0-6 0s-4 2-6-1" fill="currentColor"/></symbol>
 <symbol id="i-search" viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4 4"/></symbol>
 <symbol id="i-bag" viewBox="0 0 24 24"><path d="M5 8h14l1 13H4L5 8Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/></symbol>
 <symbol id="i-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/></symbol>
 <symbol id="i-arrow" viewBox="0 0 24 24"><path d="M4 12h15m-6-6 6 6-6 6"/></symbol>
 <symbol id="i-heart" viewBox="0 0 24 24"><path d="M20 5c-3-3-6-1-8 1-2-2-5-4-8-1-5 5 4 12 8 15 4-3 13-10 8-15Z"/></symbol>
 <symbol id="i-truck" viewBox="0 0 24 24"><path d="M2 4h12v13H2zM14 9h4l4 5v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></symbol>
 <symbol id="i-shield" viewBox="0 0 24 24"><path d="m12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6l8-4Z"/><path d="m8 11 3 3 5-5"/></symbol>
 <symbol id="i-star" viewBox="0 0 24 24"><path d="m12 2 3 6 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1 3-6Z"/></symbol>
 <symbol id="i-bone" viewBox="0 0 24 24"><path d="M7 3a3 3 0 0 0-5 3c-2 3 1 6 4 4l8 8c-2 3 1 6 4 4a3 3 0 0 0 3-5L7 3Z"/></symbol>
 <symbol id="i-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 2v6m10-6v6M3 11h18m-13 5h3"/></symbol>
 <symbol id="i-pin" viewBox="0 0 24 24"><path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></symbol>
 <symbol id="i-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></symbol>
 <symbol id="i-check" viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></symbol>
 <symbol id="i-close" viewBox="0 0 24 24"><path d="m6 6 12 12M6 18 18 6"/></symbol>
 <symbol id="i-menu" viewBox="0 0 24 24"><path d="M3 6h18M3 12h18M3 18h18"/></symbol>
 <symbol id="i-mail" viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="m3 6 9 7 9-7"/></symbol>
 <symbol id="i-scissors" viewBox="0 0 24 24"><circle cx="5" cy="5" r="3"/><circle cx="5" cy="19" r="3"/><path d="m7 7 14 14M7 17 21 3M12 12l3-3"/></symbol>
</svg>
<div class="announcement"><span>Carinho que chega até você.</span> Frete grátis a partir de R$ 149 <span class="announcement-paw"><?= icon('paw') ?></span></div>
<header class="site-header">
 <div class="container header-main">
  <a class="brand" href="index.php" aria-label="Pata e Prosa, início"><span class="brand-icon"><?= icon('paw') ?></span><span>pata<span class="brand-amp">&</span>prosa<small>UMA VIDA BOA DE PET.</small></span></a>
  <form class="header-search" action="catalogo.php" role="search"><label class="sr-only" for="search">O que seu pet precisa?</label><input id="search" name="q" placeholder="O que seu pet precisa hoje?" autocomplete="off"><button aria-label="Buscar produtos"><?= icon('search') ?></button></form>
  <div class="header-actions"><a href="conta.php" class="account-link" aria-label="Minha conta"><?= icon('user') ?><span><small>Olá, que bom te ver!</small><b data-user-label>Entre ou cadastre-se</b></span></a><a class="cart-link" href="carrinho.php" aria-label="Ver carrinho"><?= icon('bag') ?><span data-cart-count>0</span></a><button class="menu-toggle icon-btn" aria-label="Abrir menu" aria-expanded="false" aria-controls="main-nav"><?= icon('menu') ?></button></div>
 </div>
 <nav class="main-nav" id="main-nav" aria-label="Menu principal"><div class="container nav-inner"><a href="catalogo.php" class="nav-catalog <?= $page === 'catalog' ? 'active' : '' ?>"><?= icon('paw') ?> Todos os produtos</a><a href="catalogo.php?categoria=1">Ração</a><a href="catalogo.php?categoria=2">Brinquedos</a><a href="catalogo.php?categoria=3">Higiene</a><a href="catalogo.php?categoria=4">Acessórios</a><a href="catalogo.php?categoria=5">Roupinhas</a><span class="nav-divider"></span><a href="agendamento.php" class="<?= $page === 'booking' ? 'active' : '' ?>">Banho, tosa & cuidado</a><a href="sobre.php">Nossa história</a><a href="contato.php">Contato</a></div></nav>
</header>
<main id="main">
<noscript><div class="container notice">Ative o JavaScript para explorar o catálogo, usar a sacola e acessar sua conta.</div></noscript>
<?php }
function icon(string $name, string $class = ''): string { return '<svg class="icon '.htmlspecialchars($class).'" aria-hidden="true"><use href="#i-'.htmlspecialchars($name).'"/></svg>'; }
function page_end(): void { ?>
</main>
<section class="footer-invite"><div class="container"><div><?= icon('paw') ?><p>Para cada patinha,<br><strong>um mundo de carinho.</strong></p></div><a class="btn btn-light" href="agendamento.php">Vamos cuidar do seu pet <?= icon('arrow') ?></a></div></section>
<footer class="site-footer"><div class="container footer-grid"><div><a class="brand" href="index.php"><span class="brand-icon"><?= icon('paw') ?></span><span>pata<span class="brand-amp">&</span>prosa<small>UMA VIDA BOA DE PET.</small></span></a><p>A gente cuida de quem faz<br>a sua vida mais feliz.</p><span class="footer-note">Feito com carinho. E alguns pelos.</span></div><div><h3>Explore</h3><a href="catalogo.php">Nossos produtos</a><a href="agendamento.php">Serviços para seu pet</a><a href="sobre.php">Nossa história</a><a href="contato.php">Fale com a gente</a></div><div><h3>Conte com a gente</h3><a href="conta.php">Minha conta</a><a href="conta.php#pedidos">Meus pedidos</a><a href="contato.php?assunto=Entrega">Entrega e atendimento</a><a href="contato.php?assunto=Trocas">Trocas e devoluções</a></div><div><h3>Uma visita, um carinho</h3><p>Rua dos Girassóis, 128 · Vila Madalena<br>São Paulo, SP</p><p>Seg a sex, 9h às 18h<br>Sábado, 9h às 17h</p><a href="contato.php">oi@pataeprosa.example</a></div></div><div class="container footer-bottom"><span>© <?= date('Y') ?> Pata & Prosa. Todos os direitos reservados.</span><span>Loja demonstrativa · marca e dados fictícios</span><span><?= icon('shield') ?> Compra simulada e segura</span></div></footer>
<div class="toast-region" aria-live="polite" aria-atomic="true" id="toasts"></div>
<dialog id="confirm-dialog"><form method="dialog"><button class="dialog-close icon-btn" value="cancel" aria-label="Fechar"><?= icon('close') ?></button><h2 id="confirm-title">Tudo certo!</h2><p id="confirm-message"></p><button class="btn btn-primary" value="ok">Entendi <?= icon('check') ?></button></form></dialog>
</body></html>
<?php }
