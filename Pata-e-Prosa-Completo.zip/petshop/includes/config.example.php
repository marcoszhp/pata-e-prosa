<?php
// Copy to config.local.php and fill in your MySQL connection.
return [
    'configured' => true,
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'pata_prosa',
    'db_user' => 'root',
    'db_password' => '', // XAMPP defaults to an empty password on local installations.
    'timezone' => 'America/Sao_Paulo',
];
