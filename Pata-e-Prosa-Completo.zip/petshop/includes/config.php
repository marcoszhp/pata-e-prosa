<?php
declare(strict_types=1);

// Never commit config.local.php: it contains your local database credentials.
$localFile = __DIR__ . '/config.local.php';
$local = is_file($localFile) ? require $localFile : [];
if (!is_array($local)) {
    throw new RuntimeException('config.local.php deve retornar um array.');
}
$env = static function (string $key, mixed $fallback): mixed {
    $value = getenv($key);
    return $value === false ? $fallback : $value;
};

return array_replace([
    'configured' => is_file($localFile) || (getenv('DB_NAME') !== false && getenv('DB_NAME') !== ''),
    'db_host' => $env('DB_HOST', '127.0.0.1'),
    'db_port' => $env('DB_PORT', '3306'),
    'db_name' => $env('DB_NAME', 'pata_prosa'),
    'db_user' => $env('DB_USER', 'root'),
    'db_password' => $env('DB_PASSWORD', ''),
    'timezone' => 'America/Sao_Paulo',
], $local);
