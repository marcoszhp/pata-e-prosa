<?php
declare(strict_types=1);

function pp_config(): array
{
    static $config;
    return $config ??= require __DIR__ . '/config.php';
}

date_default_timezone_set(pp_config()['timezone']);
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.gc_maxlifetime', '604800');
session_name('pata_prosa_session');
$cookiePath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
session_set_cookie_params([
    'lifetime' => 604800,
    'path' => rtrim($cookiePath, '/') . '/',
    'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
if (!isset($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function pp_json(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, private');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

function pp_fail(string $message, int $status = 422, array $errors = []): never
{
    $data = ['ok' => false, 'message' => $message];
    if ($errors) {
        $data['errors'] = $errors;
    }
    pp_json($data, $status);
}

function pp_db(): PDO
{
    static $connection;
    if ($connection instanceof PDO) {
        return $connection;
    }
    $config = pp_config();
    if (!$config['configured']) {
        pp_fail('O catálogo está em modo de demonstração. Configure o banco de dados conforme o README para usar sua conta, pedidos e agendamentos.', 503);
    }
    $connection = new PDO(
        sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $config['db_host'], $config['db_port'], $config['db_name']),
        $config['db_user'],
        $config['db_password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
    );
    return $connection;
}

function pp_user(): ?array
{
    if (!isset($_SESSION['user_id']) || !pp_config()['configured']) {
        return null;
    }
    $statement = pp_db()->prepare('SELECT id, nome, email, telefone, endereco FROM usuarios WHERE id = ?');
    $statement->execute([$_SESSION['user_id']]);
    $user = $statement->fetch();
    if (!$user) {
        unset($_SESSION['user_id']);
        return null;
    }
    $user['id'] = (int) $user['id'];
    return $user;
}

function pp_require_user(): array
{
    pp_db();
    $user = pp_user();
    if (!$user) {
        pp_fail('Entre na sua conta para continuar.', 401);
    }
    return $user;
}

function pp_input(): array
{
    if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 65536) {
        pp_fail('O conteúdo enviado é muito grande.', 413);
    }
    $raw = file_get_contents('php://input', false, null, 0, 65537);
    if ($raw === false || strlen($raw) > 65536) {
        pp_fail('O conteúdo enviado é muito grande.', 413);
    }
    try {
        $value = json_decode($raw ?: '{}', true, 32, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        pp_fail('Não foi possível ler os dados enviados.', 400);
    }
    if (!is_array($value) || (array_is_list($value) && $value !== [])) {
        pp_fail('Envie um objeto JSON válido.', 400);
    }
    return $value;
}

function pp_string(array $input, string $key): string
{
    return isset($input[$key]) && is_string($input[$key]) ? trim($input[$key]) : '';
}

function pp_length(string $text): int
{
    return function_exists('mb_strlen') ? mb_strlen($text, 'UTF-8') : strlen($text);
}

function pp_validate_profile(array $input, bool $emailRequired = false): array
{
    $name = pp_string($input, 'nome');
    $phone = pp_string($input, 'telefone');
    $address = pp_string($input, 'endereco');
    $errors = [];
    if (pp_length($name) < 2 || pp_length($name) > 100) {
        $errors['nome'] = 'Informe um nome entre 2 e 100 caracteres.';
    }
    if ($phone !== '' && (!preg_match('/^[0-9+() .-]{8,30}$/', $phone) || strlen(preg_replace('/\D/', '', $phone)) < 8)) {
        $errors['telefone'] = 'Informe um telefone válido.';
    }
    if (pp_length($address) > 1000) {
        $errors['endereco'] = 'Use até 1.000 caracteres no endereço.';
    }
    if ($emailRequired) {
        $email = pp_string($input, 'email');
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) {
            $errors['email'] = 'Informe um e-mail válido.';
        }
    }
    if ($errors) {
        pp_fail('Confira os campos destacados.', 422, $errors);
    }
    return [$name, $phone, $address];
}

function pp_product_types(array $product): array
{
    foreach (['id', 'categoria_id', 'estoque', 'destaque'] as $key) {
        $product[$key] = (int) $product[$key];
    }
    $product['preco'] = (float) $product['preco'];
    $product['preco_anterior'] = $product['preco_anterior'] === null ? null : (float) $product['preco_anterior'];
    return $product;
}

/** Convert DECIMAL database money into integer cents without floating-point arithmetic. */
function pp_cents(string $money): int
{
    [$whole, $fraction] = array_pad(explode('.', $money, 2), 2, '');
    return ((int) $whole * 100) + (int) str_pad(substr($fraction, 0, 2), 2, '0');
}

function pp_decimal(int $cents): string
{
    return intdiv($cents, 100) . '.' . str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT);
}

function pp_order_response(array $order): array
{
    return [
        'id' => (int) $order['id'],
        'status' => $order['status'],
        'subtotal' => (float) $order['subtotal'],
        'desconto' => (float) $order['desconto'],
        'frete' => (float) $order['frete'],
        'total' => (float) $order['total'],
    ];
}
