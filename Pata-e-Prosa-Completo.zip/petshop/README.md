# Pata & Prosa — petshop

Loja demonstrativa com identidade visual própria, catálogo, carrinho, conta de cliente, pedidos e agendamento de serviços. Os produtos, preços, depoimentos, marca e dados da loja são fictícios. O checkout registra um pedido de demonstração: não cobra dinheiro nem processa pagamentos.

## Requisitos

- PHP 8.1 ou superior, com as extensões PDO e `pdo_mysql`; `mbstring` é recomendada.
- MySQL 8+ ou MariaDB 10.4+.
- Apache do XAMPP/WAMP, ou o servidor local incluído no PHP.
- Navegador atual. Não há etapa de compilação nem dependência de npm.

## Instalação no XAMPP ou WAMP

1. Copie esta pasta com o nome `petshop` para `C:\xampp\htdocs\petshop` (XAMPP) ou `C:\wamp64\www\petshop` (WAMP). Copie a pasta inteira; `assets` fica ao lado de `public`.
2. Inicie **Apache** e **MySQL/MariaDB** pelo painel do ambiente.
3. Abra `http://localhost/phpmyadmin`, entre em **Importar** e importe `sql/schema.sql`. O arquivo cria o banco `pata_prosa`, as tabelas e o catálogo de exemplo. Em uma instalação nova não é necessário criar produtos manualmente.
4. Copie `includes/config.example.php` para `includes/config.local.php` e ajuste a conexão:

```php
<?php
return [
    'configured' => true,
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'pata_prosa',
    'db_user' => 'root',
    'db_password' => '',
    'timezone' => 'America/Sao_Paulo',
];
```

5. Acesse **http://localhost/petshop/public/**. Cadastre sua conta pelo próprio site para testar pedidos, histórico, edição dos dados e agendamentos.

O usuário `root` sem senha é apenas o padrão de alguns ambientes XAMPP locais. Use o usuário e a senha configurados no seu banco. Mantenha `config.local.php` fora do versionamento.

## Alternativa: servidor local do PHP

Com o banco importado e a conexão configurada, abra um terminal na pasta `petshop` e execute:

```powershell
php -S 127.0.0.1:8085 -t . scripts/router.php
```

Acesse **http://127.0.0.1:8085/public/**. O servidor deve iniciar na pasta `petshop`, pois as imagens, fontes e estilos ficam em `assets`. O roteador restringe o acesso HTTP às pastas públicas. Esse servidor é destinado ao desenvolvimento local.

Também é possível configurar `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER` e `DB_PASSWORD` como variáveis de ambiente, sem criar `config.local.php`. Se o arquivo local existir, seus valores prevalecem sobre essas variáveis.

## Preview assistido nesta máquina (opcional)

Se esta pasta já contiver o runtime local em `.runtime`, os scripts abaixo reutilizam o PHP e o MariaDB portáteis preparados para a validação. Eles não baixam programas, não reinstalam o banco e não criam serviços do Windows. Essa pasta é local, não faz parte do código versionado; em outra instalação use XAMPP/WAMP conforme as instruções anteriores.

Execute na pasta `petshop`:

```powershell
.\scripts\start-preview.ps1
```

Abra **http://127.0.0.1:8085/public/**. O script inicia os processos em segundo plano, restritos a `127.0.0.1`: PHP na porta `8085` e MariaDB na `3307`. Ele reutiliza processos que já estejam ativos e lê a credencial de `.runtime/db-password.txt` sem imprimi-la. A configuração é enviada somente aos processos iniciados; as variáveis do terminal são restauradas ao fim do script.

O preview assistido exige que não exista `includes/config.local.php` nesta cópia, para que uma configuração de outro banco não prevaleça sobre o ambiente local. Para iniciar também o servidor do banco isolado de testes na porta `8086`, use `-WithTests`:

```powershell
.\scripts\start-preview.ps1 -WithTests
```

Para encerrar os servidores e solicitar a parada normal do banco, preservando todos os dados:

```powershell
.\scripts\stop-preview.ps1
```

Os scripts conferem os identificadores e os executáveis dos processos antes de reutilizá-los ou encerrá-los. Logs e registros dos processos ficam em `.runtime`. Mantenha essa pasta privada, pois ela contém os dados e a credencial do banco local.

## Visualização sem banco

Sem `config.local.php` e sem `DB_NAME`, o site mostra o catálogo fictício em modo de demonstração. O carrinho permanece disponível no navegador. Cadastro, login, pedidos e agendamentos exigem o banco configurado. A aplicação informa essa limitação na interface; ela não simula a gravação desses dados.

Abra o site por HTTP em um servidor PHP. Abrir os arquivos diretamente com `file://` não executa o backend.

## Estrutura

```text
petshop/
├── public/                Interface e API PHP
├── includes/              Conexão, sessão, validações e catálogo de demonstração
├── assets/                Estilos, JavaScript, imagens e fontes
├── sql/schema.sql         Banco, tabelas e dados iniciais
├── scripts/               Roteador local e verificação de sintaxe
├── tests/                 Verificações de integração
└── README.md
```

## Dados e personalização

Os produtos iniciais possuem nomes, descrições, preços, categorias e estoque. Para trocar as ilustrações fictícias por fotografias reais, coloque imagens licenciadas em `assets/images` e atualize `produtos.imagem_url` no banco. Os comentários de `includes/demo-products.php` e `sql/schema.sql` também indicam os caminhos utilizados na demonstração.

Texto institucional, endereço, mapa, telefone, promoções e depoimentos são exemplos. Substitua esses dados pelos dados reais antes de disponibilizar a loja ao público. Não há envio de e-mail ou integração com pagamento, frete ou agenda de terceiros.

O cadastro cria a conta já autenticada. Não há uma senha de administrador predefinida. Os produtos podem ser gerenciados diretamente pelo phpMyAdmin; o painel administrativo opcional não está incluído.

## Páginas e regras da demonstração

| Página | Arquivo em `public` |
| --- | --- |
| Início | `index.php` |
| Catálogo com busca, categorias e ordenação | `catalogo.php` |
| Detalhes do produto | `produto.php?id=1` |
| Carrinho | `carrinho.php` |
| Cadastro / Login | `cadastro.php` / `login.php` |
| Dados, pedidos e agendamentos do cliente | `conta.php` |
| Serviços | `agendamento.php` |
| Sobre a loja | `sobre.php` |
| Contato e mapa | `contato.php` |
| Finalização simulada | `checkout.php` |

- `PRIMEIROPASSEIO` concede 10% de desconto no primeiro pedido da conta.
- Frete grátis a partir de R$ 149,00 **após o desconto**; abaixo disso, o valor demonstrativo é R$ 14,90.
- Pix, cartão e boleto são opções ilustrativas. Nenhum dado de cartão é coletado e nenhum pagamento é cobrado.
- Ao concluir, pedido e itens são gravados e o estoque é reduzido em uma transação. Reenviar o mesmo identificador de pedido não cria uma segunda compra.
- Serviços: banho completo, banho e tosa, consulta veterinária. Horários de segunda a sábado, das 09h às 17h, de hora em hora, nos próximos 90 dias. A demonstração considera um profissional: apenas uma reserva por horário, independentemente do serviço.
- O contato grava a mensagem na tabela `mensagens` e limita envios repetidos. Não envia e-mail.

## Segurança e comportamento

O backend usa PDO com consultas preparadas, `password_hash`/`password_verify`, sessão PHP e cookies `HttpOnly`/`SameSite`. O carrinho é mantido no navegador, enquanto preço, estoque e total do pedido são validados novamente no servidor. A configuração do banco deve permanecer privada.

Operações de gravação exigem token CSRF. A sessão usa cookie de até 7 dias; o armazenamento de sessões do servidor também precisa preservar esse prazo. Falhas de login possuem limitação por sessão, que deve ser complementada por limites de acesso na infraestrutura de uma loja pública.

Para uma publicação comercial, configure HTTPS, credenciais próprias com privilégios limitados, backups e as integrações reais de pagamento, entrega e comunicação. As regras de acesso do Apache devem permanecer habilitadas; não publique as pastas de configuração, SQL, testes ou runtimes como arquivos estáticos.

## Verificação de sintaxe

Em PowerShell, com PHP disponível:

```powershell
.\scripts\check.ps1
# Se o PHP estiver fora do PATH:
.\scripts\check.ps1 -Php 'C:\xampp\php\php.exe'
```

## Testes de integração com banco real

`tests/integration.php` verifica autenticação, validações, CSRF, privacidade entre contas, perfil, pedidos, desconto/frete, preço adulterado, estoque, repetição de checkout, agendamentos e contato. Requer também a extensão `curl` do PHP. Os testes criam dados próprios e os removem ao terminar.

Para preservar os dados criados pela suíte para inspeção, acrescente `--keep-fixtures` após a URL. Essa opção mantém as contas, os produtos e os registros exclusivos daquela execução no banco de teste.

Use uma **cópia separada do projeto** com um banco exclusivo chamado `pata_prosa_test`. Na cópia de `schema.sql`, troque somente `CREATE DATABASE IF NOT EXISTS pata_prosa` e `USE pata_prosa;` por `CREATE DATABASE IF NOT EXISTS pata_prosa_test` e `USE pata_prosa_test;`, e importe essa cópia. Configure o servidor dessa cópia para o banco de teste.

No PowerShell da cópia, defina as credenciais do banco de teste e inicie o servidor. Se houver `config.local.php`, ele também precisa apontar para esse mesmo banco, porque seus valores prevalecem sobre o ambiente:

```powershell
$env:DB_HOST = '127.0.0.1'
$env:DB_PORT = '3306'
$env:DB_NAME = 'pata_prosa_test'
$env:DB_USER = 'root'
$env:DB_PASSWORD = '' # Ajuste conforme seu banco local.
php -S 127.0.0.1:8086 -t . scripts/router.php
```

Em outro terminal, defina as mesmas cinco variáveis e execute:

```powershell
php tests/integration.php http://127.0.0.1:8086/public
```

O teste recusa bancos cujo nome não termine em `_test`, aceita somente URLs locais e confirma, por um produto temporário exclusivo, que a API está conectada ao banco informado antes de criar contas ou pedidos.

Validação realizada nesta entrega: PHP 8.3.35 + MariaDB 11.4.8, com 39 verificações de integração aprovadas. O relatório `tests/VALIDACAO.md` registra também os cenários da interface e a revisão em telas pequenas. O servidor Apache do XAMPP/WAMP e o MySQL Oracle não foram executados neste ambiente; a configuração para esses ambientes está documentada acima.

## Publicação no GitHub Pages

O projeto inclui uma exportação estática para o GitHub Pages. A publicação mantém o visual, o GIF, as páginas institucionais, os 12 produtos fictícios, os filtros, a busca, a ordenação, os detalhes dos produtos e a sacola persistente no navegador.

**GitHub Pages não executa PHP nem MySQL.** Por isso, login e cadastro não pedem credenciais nessa versão; pedidos, histórico, edição de dados, mensagens e agendamentos não são gravados. Os formulários mostram a limitação com mensagens estilizadas. A aplicação PHP/MySQL original continua completa em `public/` e `includes/`, para hospedagem compatível.

Gere os arquivos públicos a partir da raiz de `petshop`:

```powershell
php scripts/build-pages.php
# Com PHP instalado pelo XAMPP:
& 'C:\xampp\php\php.exe' scripts/build-pages.php
```

O resultado fica em `dist/`, com páginas `.html` e caminhos relativos compatíveis com `https://USUARIO.github.io/REPOSITORIO/`. Copie **somente o conteúdo de `dist/`** para a pasta `docs/` do repositório de publicação. Nas configurações desse repositório, selecione **Pages → Deploy from a branch → main → /docs**. O build inclui `.nojekyll` e valida uma lista de arquivos permitidos: API, configuração do banco, SQL, testes e runtimes não são publicados. `dist/` é gerado e não deve ser editado manualmente.

Endereço da vitrine publicada: <https://marcoszhp.github.io/pata-e-prosa/>. Repositório: <https://github.com/marcoszhp/pata-e-prosa>.

Para mudanças futuras, atualize os templates, estilos ou o catálogo de exemplo e gere a exportação novamente. O script adapta apenas a cópia de `app.js` em `dist/`; o aplicativo PHP local permanece inalterado. A sacola salva somente identificadores e quantidades de produtos. Não há armazenamento de senhas, contas ou pedidos no navegador.

## Solução de problemas

| Sintoma | O que conferir |
| --- | --- |
| `could not find driver` | Ative `extension=pdo_mysql` no `php.ini` usado pelo servidor e reinicie o PHP/Apache. |
| Banco indisponível | Verifique se MySQL/MariaDB está iniciado, se o schema foi importado e se host, porta, banco e senha estão corretos. |
| O site permanece em demonstração | Crie `includes/config.local.php` com `configured => true`, ou defina `DB_NAME` no ambiente do processo PHP. |
| Estilos ou imagens não carregam | Copie a pasta inteira e acesse `/petshop/public/`; no servidor embutido, inicie na raiz de `petshop` usando o roteador acima. |
| Login não permanece | Permita cookies do site e mantenha o mesmo endereço (não alterne entre `localhost` e `127.0.0.1`). Verifique permissão de gravação da pasta de sessões do PHP. |
| Porta ocupada | Escolha outra porta no servidor PHP, por exemplo `8086`, e atualize a URL. A porta do banco é configurada separadamente. |
| Erro ao importar SQL | Importe o arquivo completo usando uma conta com permissão para criar bancos e tabelas; a versão mínima está nos requisitos. |
