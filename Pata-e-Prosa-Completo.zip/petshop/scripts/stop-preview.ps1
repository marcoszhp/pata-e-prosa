$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
$runtimePath = Join-Path $projectPath '.runtime'
$phpExe = Join-Path $runtimePath 'php\php.exe'
$databaseExe = Join-Path $runtimePath 'mariadb\mariadb-11.4.8-winx64\bin\mariadbd.exe'
$databaseAdmin = Join-Path $runtimePath 'mariadb\mariadb-11.4.8-winx64\bin\mariadb-admin.exe'

function Get-OwnedProcess([string]$Name, [string]$Executable) {
    $pidFile = Join-Path $runtimePath "$Name.pid"
    if (-not (Test-Path -LiteralPath $pidFile -PathType Leaf)) { return $null }
    $savedId = 0
    if (-not [int]::TryParse((Get-Content -LiteralPath $pidFile -Raw).Trim(), [ref]$savedId)) {
        throw "Registro de processo inválido: $pidFile"
    }
    $savedProcess = Get-Process -Id $savedId -ErrorAction SilentlyContinue
    if ($savedProcess -and $savedProcess.Path -ne $Executable) {
        throw "O registro $pidFile aponta para outro programa. Nenhum processo com esse registro será encerrado."
    }
    return $savedProcess
}

foreach ($serverName in @('php-test', 'php')) {
    $serverProcess = Get-OwnedProcess $serverName $phpExe
    if ($serverProcess) {
        Stop-Process -Id $serverProcess.Id
        $serverProcess.WaitForExit(10000) | Out-Null
    }
}

$databaseProcess = Get-OwnedProcess 'mysql' $databaseExe
if ($databaseProcess) {
    $passwordFile = Join-Path $runtimePath 'db-password.txt'
    if (-not (Test-Path -LiteralPath $databaseAdmin -PathType Leaf) -or -not (Test-Path -LiteralPath $passwordFile -PathType Leaf)) {
        throw 'O utilitário de parada ou a credencial local não foi encontrado. O banco foi mantido em execução para evitar uma parada forçada.'
    }
    $previousPassword = [Environment]::GetEnvironmentVariable('MYSQL_PWD', 'Process')
    try {
        $env:MYSQL_PWD = Get-Content -LiteralPath $passwordFile -Raw
        & $databaseAdmin '--host=127.0.0.1' '--port=3307' '--user=root' 'shutdown'
        if ($LASTEXITCODE -ne 0) { throw 'O banco não aceitou a parada normal; confira os logs em .runtime. Nenhuma parada forçada foi realizada.' }
        if (-not $databaseProcess.WaitForExit(10000)) { throw 'O banco ainda está concluindo a parada. Confira .runtime/mysql.stderr.log.' }
    } finally {
        [Environment]::SetEnvironmentVariable('MYSQL_PWD', $previousPassword, 'Process')
    }
}
Write-Host 'Preview local encerrado. Dados e runtimes foram preservados.'
