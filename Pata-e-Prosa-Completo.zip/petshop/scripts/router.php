<?php
declare(strict_types=1);

// Local PHP server: php -S 127.0.0.1:8085 -t . scripts/router.php
// Apache installations use the .htaccess rules instead of this router.
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
if ($path === '/') {
    header('Location: /public/');
    exit;
}
if (!preg_match('#^/(?:public|assets)/#', $path) || str_contains($path, '..') || str_contains($path, '\\') || preg_match('#/\.[^/]*#', $path)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Página não encontrada.';
    return true;
}
return false;
