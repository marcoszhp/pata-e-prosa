param([string]$Php = 'php')

$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
$phpFiles = @('public', 'includes', 'scripts', 'tests') | ForEach-Object {
    $sourcePath = Join-Path $projectPath $_
    if (Test-Path -LiteralPath $sourcePath) {
        Get-ChildItem -LiteralPath $sourcePath -Filter '*.php' -File -Recurse
    }
}
foreach ($sourceFile in $phpFiles) {
    & $Php -l $sourceFile.FullName
    if ($LASTEXITCODE -ne 0) { throw "Falha na sintaxe de $($sourceFile.Name)." }
}
Write-Host "$($phpFiles.Count) arquivos PHP verificados."
