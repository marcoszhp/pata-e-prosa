<?php
declare(strict_types=1);

/** Build the public GitHub Pages demo. The PHP/MySQL application is unchanged. */
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$root = dirname(__DIR__);
$output = $root . '/dist';

function write_output(string $path, string $content): void
{
    if (!is_dir(dirname($path)) && !mkdir(dirname($path), 0755, true)) {
        throw new RuntimeException('Could not create output directory.');
    }
    if (file_put_contents($path, $content) === false) {
        throw new RuntimeException('Could not write ' . $path);
    }
}

function render_page(string $file): string
{
    // Each page gets a clean PHP process: layout helpers cannot collide and no DB is needed.
    $process = proc_open([PHP_BINARY, '-d', 'display_errors=stderr', $file],
        [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']], $pipes, dirname($file));
    if (!is_resource($process)) {
        throw new RuntimeException('Could not start PHP renderer.');
    }
    fclose($pipes[0]);
    $html = stream_get_contents($pipes[1]);
    $error = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    $status = proc_close($process);
    if ($status !== 0 || $error !== '' || !str_contains($html, '<!doctype html>')) {
        throw new RuntimeException('Page rendering failed: ' . basename($file) . ' ' . $error);
    }
    return $html;
}

function page_links(string $text): string
{
    return str_replace(['../assets/', '.php'], ['./assets/', '.html'], $text);
}

try {
    // Explicit allowlist prevents APIs, configuration, runtimes and SQL from becoming public assets.
    $pages = ['index', 'catalogo', 'produto', 'carrinho', 'login', 'cadastro', 'conta', 'agendamento', 'sobre', 'contato', 'checkout'];
    $allowedAssets = ['css/style.css', 'css/pages.css', 'js/app.js', 'js/pages-adapter.js', 'SOURCES.md'];
    foreach (['fonts', 'images'] as $folder) {
        foreach (glob($root . '/assets/' . $folder . '/*') as $file) {
            if (is_file($file) && !is_link($file)) {
                $allowedAssets[] = $folder . '/' . basename($file);
            }
        }
    }

    require $root . '/includes/demo-products.php';
    $products = pp_demo_products();
    foreach ($products as &$product) {
        $product['imagem_url'] = str_replace('../assets/', './assets/', $product['imagem_url']);
    }
    unset($product);
    $seed = json_encode($products, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_THROW_ON_ERROR);
    $notice = '<aside class="pages-banner" aria-label="Sobre esta demonstração"><div class="container"><strong>Uma vitrine cheia de carinho.</strong><span>Demonstração no GitHub Pages · explore os produtos e a sacola. Conta, pedidos e agenda precisam da versão PHP/MySQL.</span></div></aside>';
    $accountCard = '<div class="auth-card pages-account"><span class="eyebrow">VOCÊ ESTÁ NA NOSSA VITRINE</span><h2>Todo o carinho, em uma prévia.</h2><p>Explore nossos mimos e monte sua sacola à vontade. Nesta demonstração no GitHub Pages, cadastro e login estão indisponíveis.</p><div class="notice">A área do cliente, o histórico de pedidos e os agendamentos funcionam na versão com servidor PHP e banco MySQL. Esta prévia não coleta senhas nem cria contas.</div><a class="btn btn-primary" href="catalogo.html">Explorar os produtos <svg class="icon" aria-hidden="true"><use href="#i-arrow"/></svg></a><a class="text-link" href="carrinho.html">Voltar para minha sacola</a></div>';

    foreach ($pages as $page) {
        // cadastro.php is an HTTP redirect; both static entry points show the same explicit account limitation.
        $html = render_page($root . '/public/' . ($page === 'cadastro' ? 'login' : $page) . '.php');
        $html = page_links($html);
        $html = str_replace('<body data-page=', '<body data-hosting="github-pages" data-page=', $html);
        $html = str_replace('<script src="./assets/js/app.js" defer></script>',
            '<link rel="stylesheet" href="./assets/css/pages.css">' . "\n" .
            '<script id="pages-products" type="application/json">' . $seed . '</script>' . "\n" .
            '<script src="./assets/js/pages-adapter.js" defer></script>' . "\n" .
            '<script src="./assets/js/app.js" defer></script>', $html);
        $html = str_replace('<main id="main">', $notice . "\n<main id=\"main\">", $html);

        if (in_array($page, ['login', 'cadastro'], true)) {
            $html = preg_replace('~<div class="auth-card">.*?</div></div></div></section>~s', $accountCard . '</div></section>', $html, 1, $count);
            if ($count !== 1) {
                throw new RuntimeException('The login template changed; account export must be reviewed.');
            }
        }
        if (in_array($page, ['agendamento', 'contato'], true)) {
            $formId = $page === 'agendamento' ? 'booking-form' : 'contact-form';
            $explanation = $page === 'agendamento'
                ? 'Prévia do agendamento: os serviços e valores são fictícios. Reservas ficam disponíveis na versão PHP/MySQL.'
                : 'Prévia do contato: este formulário está desativado no GitHub Pages e não envia nem salva mensagens.';
            $html = preg_replace_callback('~<form\b[^>]*id="' . $formId . '"[^>]*>(.*?)</form>~s', static function ($match) use ($formId, $explanation) {
                $form = preg_replace('~<(input|select|textarea)\b~', '<$1 disabled', $match[0]);
                $form = preg_replace('~<small class="form-hint">.*?</small>~s', '<small class="form-hint">Nenhum dado é enviado ou salvo nesta prévia.</small>', $form);
                $form = str_replace('type="submit"', 'type="button" data-pages-unavailable="true"', $form);
                return '<div class="notice">' . $explanation . '</div>' . $form;
            }, $html);
            $html = str_replace(['Use o formulário para registrar sua mensagem.', 'Preencha os campos e registre sua mensagem.', 'O agendamento será salvo na sua conta. Sem pagamento agora.'],
                ['Contato ilustrativo da loja demonstrativa.', 'Conheça a prévia do nosso atendimento.', 'Nenhum agendamento é registrado nesta prévia.'], $html);
        }
        write_output($output . '/' . $page . '.html', $html);
    }

    foreach ($allowedAssets as $asset) {
        $content = file_get_contents($root . '/assets/' . $asset);
        if ($content === false) {
            throw new RuntimeException('Missing asset: ' . $asset);
        }
        if ($asset === 'js/app.js') {
            $content = page_links($content);
            // Adapt the asset's escaped regex separately from literal asset URLs.
            $content = str_replace('^\\.\\.\\/assets\\/', '^\\.\\/assets\\/', $content);
            $needle = 'async function api(action, data, query = {}) {';
            if (substr_count($content, $needle) !== 1) {
                throw new RuntimeException('The API wrapper changed; Pages adapter must be reviewed.');
            }
            $content = str_replace($needle, $needle . "\n    if (window.PataProsaPages) return window.PataProsaPages.request(action, data, query);", $content);
            $content = str_replace("if(page==='auth')setupAuth();", "if(page==='auth')window.PataProsaPages.showAccountNotice();", $content);
            $content = str_replace("if(page==='booking')setupBooking();", "if(page==='booking')window.PataProsaPages.showFormNotice();", $content);
            $content = str_replace("if(page==='contact')setupContact();", "if(page==='contact')window.PataProsaPages.showFormNotice();", $content);
            $content = str_replace("if(page==='checkout')await renderCheckout();", "if(page==='checkout')window.PataProsaPages.showCheckoutNotice();", $content);
        }
        write_output($output . '/assets/' . $asset, $content);
    }
    write_output($output . '/.nojekyll', '');
    // Validate that a reused dist directory cannot accidentally ship server-only files.
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($output, FilesystemIterator::SKIP_DOTS)) as $file) {
        $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($output) + 1));
        $allowed = $relative === '.nojekyll' || in_array($relative, array_map(static fn ($p) => $p . '.html', $pages), true)
            || in_array($relative, array_map(static fn ($p) => 'assets/' . $p, $allowedAssets), true);
        if (!$allowed || $file->isLink()) {
            throw new RuntimeException('Unexpected file in dist; inspect and remove before publishing: ' . $relative);
        }
    }
    fwrite(STDOUT, 'GitHub Pages export ready: ' . count($pages) . ' HTML pages, ' . count($products) . " fictitious products, no PHP/configuration/database files.\n");
} catch (Throwable $error) {
    fwrite(STDERR, 'Build failed: ' . $error->getMessage() . "\n");
    exit(1);
}
