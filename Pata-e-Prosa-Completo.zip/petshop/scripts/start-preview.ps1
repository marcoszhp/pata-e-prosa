param([switch]$WithTests)

$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
$runtimePath = Join-Path $projectPath '.runtime'
$phpExe = Join-Path $runtimePath 'php\php.exe'
$databaseExe = Join-Path $runtimePath 'mariadb\mariadb-11.4.8-winx64\bin\mariadbd.exe'
$databaseConfig = Join-Path $runtimePath 'db\my.ini'
$passwordFile = Join-Path $runtimePath 'db-password.txt'

foreach ($requiredPath in @($phpExe, $databaseExe, $databaseConfig, $passwordFile)) {
    if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) {
        throw 'O runtime local assistido não está disponível nesta pasta. Siga a instalação XAMPP/WAMP do README. Este script não baixa nem instala programas.'
    }
}
if (Test-Path -LiteralPath (Join-Path $projectPath 'includes\config.local.php')) {
    throw 'Há um includes/config.local.php nesta instalação. Use o servidor configurado por esse arquivo ou execute o preview assistido em uma cópia sem ele; o arquivo prevalece sobre as variáveis do preview.'
}

function Test-LocalPort([int]$Port) {
    $connection = New-Object System.Net.Sockets.TcpClient
    try {
        $attempt = $connection.ConnectAsync('127.0.0.1', $Port)
        if (-not $attempt.Wait(400)) { return $false }
        return $connection.Connected
    } catch { return $false }
    finally { $connection.Dispose() }
}

function Get-PreviewProcess([string]$PidFile, [string]$Executable) {
    if (-not (Test-Path -LiteralPath $PidFile -PathType Leaf)) { return $null }
    $savedId = 0
    if (-not [int]::TryParse((Get-Content -LiteralPath $PidFile -Raw).Trim(), [ref]$savedId)) {
        throw "Registro de processo inválido: $PidFile"
    }
    $savedProcess = Get-Process -Id $savedId -ErrorAction SilentlyContinue
    if ($savedProcess -and $savedProcess.Path -ne $Executable) {
        throw "O registro $PidFile aponta para outro programa. Nenhum processo foi alterado."
    }
    return $savedProcess
}

function Start-PreviewProcess([string]$Name, [string]$Executable, [string[]]$Arguments, [int]$Port) {
    $pidFile = Join-Path $runtimePath "$Name.pid"
    $serverProcess = Get-PreviewProcess $pidFile $Executable
    if (-not $serverProcess) {
        if (Test-LocalPort $Port) { throw "A porta $Port está ocupada por outro processo. Libere a porta antes de iniciar o preview." }
        $serverProcess = Start-Process -FilePath $Executable -ArgumentList $Arguments -WorkingDirectory $projectPath -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $runtimePath "$Name.stdout.log") -RedirectStandardError (Join-Path $runtimePath "$Name.stderr.log")
        $serverProcess.Id | Set-Content -LiteralPath $pidFile
    }
    $deadline = [DateTime]::UtcNow.AddSeconds(20)
    do {
        if (Test-LocalPort $Port) { return }
        $serverProcess.Refresh()
        if ($serverProcess.HasExited) { throw "O processo $Name encerrou. Confira .runtime/$Name.stderr.log." }
        Start-Sleep -Milliseconds 200
    } while ([DateTime]::UtcNow -lt $deadline)
    throw "O processo $Name não respondeu na porta $Port. Confira .runtime/$Name.stderr.log."
}

$savedEnvironment = @{}
foreach ($variableName in @('DB_HOST', 'DB_PORT', 'DB_NAME', 'DB_USER', 'DB_PASSWORD')) {
    $savedEnvironment[$variableName] = [Environment]::GetEnvironmentVariable($variableName, 'Process')
}

try {
    $env:DB_HOST = '127.0.0.1'
    $env:DB_PORT = '3307'
    $env:DB_USER = 'root'
    $env:DB_PASSWORD = Get-Content -LiteralPath $passwordFile -Raw
    Start-PreviewProcess 'mysql' $databaseExe @("--defaults-file=`"$databaseConfig`"", "--datadir=`"$runtimePath\db`"", '--bind-address=127.0.0.1', '--port=3307', '--console') 3307
    $env:DB_NAME = 'pata_prosa'
    Start-PreviewProcess 'php' $phpExe @('-S', '127.0.0.1:8085', '-t', '.', 'scripts/router.php') 8085
    $catalog = Invoke-RestMethod -Uri 'http://127.0.0.1:8085/public/api.php?action=products' -TimeoutSec 15
    if (-not $catalog.ok -or $catalog.demo) { throw 'O catálogo não confirmou a conexão com o banco local.' }
    Write-Host 'Preview pronto: http://127.0.0.1:8085/public/'
    if ($WithTests) {
        $env:DB_NAME = 'pata_prosa_test'
        Start-PreviewProcess 'php-test' $phpExe @('-S', '127.0.0.1:8086', '-t', '.', 'scripts/router.php') 8086
        $testCatalog = Invoke-RestMethod -Uri 'http://127.0.0.1:8086/public/api.php?action=products' -TimeoutSec 15
        if (-not $testCatalog.ok -or $testCatalog.demo) { throw 'O servidor de testes não confirmou a conexão com o banco local.' }
        Write-Host 'Servidor de testes pronto: http://127.0.0.1:8086/public/'
    }
    Write-Host 'Para encerrar: .\scripts\stop-preview.ps1'
} finally {
    foreach ($variableName in $savedEnvironment.Keys) {
        [Environment]::SetEnvironmentVariable($variableName, $savedEnvironment[$variableName], 'Process')
    }
}
